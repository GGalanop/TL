package Subscriber;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.regex.Pattern;

public class PaymentScreen {
    private boolean transaction;

    // Constructor
    public PaymentScreen() {
        this.transaction = false;
    }

    // Method to confirm transaction
    public void confirmTransaction(int userID, String creditCardInfo) {
        if (isValidCreditCard(creditCardInfo)) {
            this.transaction = true;
            updatePaymentInfo(userID, creditCardInfo);
        } else {
            this.transaction = false;
            System.out.println("Transaction failed: Invalid credit card information.");
        }
    }

    // Method to validate credit card information
    private boolean isValidCreditCard(String creditCardInfo) {
        // Simple regex for basic credit card validation (16 digits)
        String creditCardRegex = "^[0-9]{16}$";
        Pattern pattern = Pattern.compile(creditCardRegex);
        return pattern.matcher(creditCardInfo).matches();
    }

    // Method to update payment information in the database
    private void updatePaymentInfo(int userID, String creditCardInfo) {
        String updateSQL = "INSERT INTO payment_info (userID, creditCardInfo) VALUES (?, ?) " +
                           "ON DUPLICATE KEY UPDATE creditCardInfo = VALUES(creditCardInfo)";

        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/your_database", "your_username", "your_password");
             PreparedStatement preparedStatement = connection.prepareStatement(updateSQL)) {

            preparedStatement.setInt(1, userID);
            preparedStatement.setString(2, creditCardInfo);

            int rowsUpdated = preparedStatement.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Payment information updated successfully.");
            } else {
                System.out.println("Failed to update payment information.");
            }
        } catch (SQLException e) {
            System.out.println("SQL Exception: " + e.getMessage());
            e.printStackTrace();
        }
    }

    // Getter for transaction status
    public boolean isTransaction() {
        return transaction;
    }
}

