package Subscriber;


public class SubscriptionForm {
    private Subscriber subscriber;

    // Constructor
    public SubscriptionForm(Subscriber subscriber) {
        this.subscriber = subscriber;
    }

    // Getter for subscriber
    public Subscriber getSubscriber() {
        return subscriber;
    }

    // Method to submit subscription data
    public void submitData(SubscriptionController controller) {
        controller.verifyData(this);
    }
}

