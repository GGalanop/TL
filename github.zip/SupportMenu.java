import java.util.Scanner;

public class SupportMenu {
    private FAQ faq;
    private SupportController supportController;

    // Constructor
    public SupportMenu() {
        this.faq = new FAQ();
        this.supportController = new SupportController();
    }

    // Method to display the support menu
    public void displayMenu() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Support Menu:");
        System.out.println("1. FAQ");
        System.out.println("2. Support Inquiry");
        System.out.print("Enter your choice: ");

        int choice = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        switch (choice) {
            case 1:
                faq.displayFAQs();
                break;
            case 2:
                handleSupportInquiry(scanner);
                break;
            default:
                System.out.println("Invalid choice. Please try again.");
                break;
        }
    }

       // Method to handle support inquiries (continued)
       private void handleSupportInquiry(Scanner scanner) {
        System.out.print("Enter your question: ");
        String question = scanner.nextLine();

        // Simulating real-time answer from the company (in a real scenario, this would be handled asynchronously)
        System.out.print("Enter the answer: ");
        String answer = scanner.nextLine();

        // Generate a random InquiryID for demonstration purposes
        int inquiryID = (int) (Math.random() * 1000);

        // Submit the inquiry to the database
        supportController.submitInquiry(inquiryID, question, answer);

        System.out.println("Your inquiry has been submitted. Thank you!");
    }

    // Main method for testing the SupportMenu
    public static void main(String[] args) {
        SupportMenu menu = new SupportMenu();
        menu.displayMenu();
    }
}

