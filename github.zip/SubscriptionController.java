package Subscriber;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class SubscriptionController {

    // Database URL, username, and password
    private static final String DB_URL = "jdbc:mysql://localhost:3306/your_database";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "";

    // Method to verify data
    public void verifyData(SubscriptionForm form) {
        Subscriber subscriber = form.getSubscriber();
        String creditCardInfo = subscriber.getCreditCardInfo();

        // Here you would add logic to verify the data, for example checking if the credit card info is valid
        // For simplicity, let's assume the verification is always successful
        System.out.println("Verifying data for subscriber: " + subscriber);
        arrangePayment(subscriber, creditCardInfo);
    }

    // Method to arrange payment
    public void arrangePayment(Subscriber subscriber, String creditCardInfo) {
        PaymentScreen paymentScreen = new PaymentScreen();
        paymentScreen.confirmTransaction(subscriber.getUserID(), creditCardInfo);

        if (paymentScreen.isTransaction()) {
            updateSubscription(subscriber);
        } else {
            System.out.println("Transaction failed. Subscription not updated.");
        }
    }

    // Method to update subscription status
    public void updateSubscription(Subscriber subscriber) {
        String updateSQL = "UPDATE subscribers SET subscribed = ? WHERE userID = ?";
        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement preparedStatement = connection.prepareStatement(updateSQL)) {

            if (!subscriber.isSubscribed()) {
                subscriber.setSubscribed(true);
            }

            preparedStatement.setBoolean(1, subscriber.isSubscribed());
            preparedStatement.setInt(2, subscriber.getUserID());

            int rowsUpdated = preparedStatement.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Subscription status updated successfully.");
            } else {
                System.out.println("Failed to update subscription status.");
            }
        } catch (SQLException e) {
            System.out.println("SQL Exception: " + e.getMessage());
            e.printStackTrace();
        }
    }

    // Main method for testing the subscription process
    public static void main(String[] args) {
        Subscriber subscriber = new Subscriber(1);
        subscriber.setCreditCardInfo("1234567812345678");
        SubscriptionForm form = new SubscriptionForm(subscriber);

        SubscriptionController controller = new SubscriptionController();
        form.submitData(controller);
    }
}

