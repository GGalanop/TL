package Login;

public class LoginForm {
    private String email;
    private String password;

    // Constructor
    public LoginForm(String email, String password) {
        this.email = email;
        this.password = password;
    }

    // Getters
    public String getEmail() {
        return email;
    }

    public String getPassword() {
        return password;
    }

    // Method to submit login data
    public void submitData(LoginController controller) {
        controller.login(this);
    }

    // Inner class for password reset prompt
    public class PasswordResetPrompt {
        public void triggerReset() {
            System.out.println("Password reset triggered for email: " + email);
        }
    }
}
