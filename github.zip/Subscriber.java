package Subscriber;


public class Subscriber extends User {
    private boolean subscribed;
    private String creditCardInfo;

    // Constructor
    public Subscriber(int userID) {
        super(userID, "", ""); // Call the superclass constructor
        this.subscribed = false; // Default to false
        this.creditCardInfo = ""; // Default to empty string
    }

    // Getter and Setter for subscribed
    public boolean isSubscribed() {
        return subscribed;
    }

    public void setSubscribed(boolean subscribed) {
        this.subscribed = subscribed;
    }

    // Getter and Setter for creditCardInfo
    public String getCreditCardInfo() {
        return creditCardInfo;
    }

    public void setCreditCardInfo(String creditCardInfo) {
        this.creditCardInfo = creditCardInfo;
    }

    // Override toString method for easy printing
    @Override
    public String toString() {
        return "Subscriber{" +
                "userID=" + getUserID() +
                ", subscribed=" + subscribed +
                ", creditCardInfo='" + creditCardInfo + '\'' +
                '}';
    }

    // Main method for testing the Subscriber class
    public static void main(String[] args) {
        Subscriber subscriber = new Subscriber(1);
        System.out.println(subscriber); // Should print: Subscriber{userID=1, subscribed=false, creditCardInfo=''}

        subscriber.setSubscribed(true);
        subscriber.setCreditCardInfo("1234567812345678");
        System.out.println(subscriber); // Should print: Subscriber{userID=1, subscribed=true, creditCardInfo='1234567812345678'}
    }
}

