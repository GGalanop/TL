package Login;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class LoginController {

    // Database URL, username, and password
    private static final String DB_URL = "jdbc:mysql://localhost:3306/your_database";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "";

    // Method to handle login
    public void login(LoginForm form) {
        String selectSQL = "SELECT * FROM users WHERE email = ? AND password = ?";

        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement preparedStatement = connection.prepareStatement(selectSQL)) {

            preparedStatement.setString(1, form.getEmail());
            preparedStatement.setString(2, form.getPassword());

            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                displayConfirmation();
            } else {
                System.out.println("Invalid email or password.");
            }

        } catch (SQLException e) {
            System.out.println("SQL Exception: " + e.getMessage());
            e.printStackTrace();
        }
    }

    // Method to display confirmation message
    public void displayConfirmation() {
        System.out.println("Login successful! Welcome to your account.");
    }

    // Main method for testing the login process
    public static void main(String[] args) {
        LoginController controller = new LoginController();

        // Create a login form with email and password
        LoginForm form = new LoginForm("georgediamantopouos@gmail.com", "5551144");

        // Submit the login form
        form.submitData(controller);

        // Trigger password reset
        form.new PasswordResetPrompt().triggerReset();
    }
}

